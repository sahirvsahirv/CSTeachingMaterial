class SettingsException(Exception):
    """Raise exception when there are errors in the `settings.py` file 
    """
    pass
